<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['admin_user'] ?? 'Admin';
$pageTitle = 'Traffic Alerts';
$pageDescription = 'View congestion warnings, sensor faults and system notifications.';
require 'module_view.php';
?>
