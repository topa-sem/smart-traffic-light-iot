document.addEventListener("DOMContentLoaded", () => {
    const canvas = document.getElementById("predictionChart");
    if (!canvas || typeof Chart === "undefined") return;

    const context = canvas.getContext("2d");
    const gradient = context.createLinearGradient(0, 0, 0, 280);
    gradient.addColorStop(0, "rgba(0, 242, 254, 0.3)");
    gradient.addColorStop(1, "rgba(47, 129, 247, 0.02)");

    const chart = new Chart(context, {
        type: "line",
        data: {
            labels: [],
            datasets: [{
                label: "Vehicles reported",
                data: [],
                backgroundColor: gradient,
                borderColor: "#00f2fe",
                borderWidth: 2,
                tension: 0.42,
                fill: true,
                pointBackgroundColor: "#2f81f7",
                pointBorderColor: "#00f2fe",
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: "#8b949e", usePointStyle: true } },
                tooltip: {
                    backgroundColor: "rgba(13, 17, 23, .94)",
                    borderColor: "rgba(0, 242, 254, .35)",
                    borderWidth: 1,
                    titleColor: "#f0f6fc",
                    bodyColor: "#8b949e",
                    displayColors: false,
                    padding: 12
                }
            },
            scales: {
                x: { ticks: { color: "#9aa79d" }, grid: { display: false } },
                y: { beginAtZero: true, ticks: { color: "#9aa79d" },
                    grid: { color: "rgba(154,167,157,.15)" } }
            }
        }
    });

    window.addEventListener("streamlight:telemetry", event => {
        const lanes = event.detail.lanes || [];
        chart.data.labels = lanes.map(lane => lane.lane_name);
        chart.data.datasets[0].data = lanes.map(lane => Number(lane.vehicle_count));
        chart.update();
    });
});
