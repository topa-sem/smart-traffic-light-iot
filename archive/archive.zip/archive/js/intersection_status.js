document.addEventListener("DOMContentLoaded", () => {
    const laneGrid = document.getElementById("laneGrid");
    const total = document.getElementById("vehicleTotal");
    const active = document.getElementById("activeLaneCount");
    const controller = document.getElementById("controllerStatus");
    const updated = document.getElementById("lastUpdated");
    const trafficMood = document.getElementById("trafficMood");

    if (!laneGrid) return;

    function safeText(value) {
        return String(value ?? "").replace(/[&<>"']/g, char => ({
            "&": "&amp;", "<": "&lt;", ">": "&gt;",
            '"': "&quot;", "'": "&#039;"
        })[char]);
    }

    function renderLanes(lanes) {
        laneGrid.innerHTML = "";
        lanes.forEach(lane => {
            const state = String(lane.signal_state || "UNKNOWN").toUpperCase();
            const color = ["RED", "YELLOW", "GREEN"].includes(state) ? state.toLowerCase() : "";
            const card = document.createElement("article");
            card.className = "lane-card";
            card.innerHTML = `
                <p class="lane-name">${safeText(lane.lane_name)}</p>
                <p class="lane-count">${Number(lane.vehicle_count) || 0}</p>
                <span class="signal-state">
                    <span class="signal-dot ${color}"></span>${safeText(state)}
                </span>`;
            laneGrid.appendChild(card);
        });
        if (!lanes.length) laneGrid.innerHTML = '<p class="empty-state">No lane data received.</p>';
    }

    function updateTrafficMood(status, lanes) {
        if (!trafficMood) return;

        const hasRed = lanes.some(lane => String(lane.signal_state || "").toUpperCase() === "RED");
        const hasYellow = lanes.some(lane => String(lane.signal_state || "").toUpperCase() === "YELLOW");
        let mood = { className: "chip-green", icon: "fa-circle-check", label: "All green" };

        if (status !== "online") {
            mood = { className: "chip-red", icon: "fa-triangle-exclamation", label: "Feed unavailable" };
        } else if (hasRed) {
            mood = { className: "chip-red", icon: "fa-triangle-exclamation", label: "Attention needed" };
        } else if (hasYellow) {
            mood = { className: "chip-orange", icon: "fa-hourglass-half", label: "Rush hour active" };
        }

        trafficMood.className = `status-chip ${mood.className}`;
        trafficMood.innerHTML = `<i class="fa-solid ${mood.icon}"></i> ${mood.label}`;
    }

    async function refresh() {
        try {
            const response = await fetch("/smarttraffic/api_telemetry.php", { cache: "no-store" });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const data = await response.json();
            if (!Array.isArray(data.lanes)) throw new Error("API did not return a lanes array");

            renderLanes(data.lanes);
            updateTrafficMood(data.status, data.lanes);
            total.textContent = data.lanes.reduce((sum, lane) => sum + (Number(lane.vehicle_count) || 0), 0);
            active.textContent = data.lanes.length;
            const isOnline = data.status === "online";
            controller.textContent = isOnline ? "Online" : "Offline";
            controller.classList.toggle("status-online", isOnline);
            controller.classList.toggle("status-offline", !isOnline);
            controller.classList.remove("status-checking");
            updated.textContent = `Updated ${new Date().toLocaleTimeString()}`;
            window.dispatchEvent(new CustomEvent("streamlight:telemetry", { detail: data }));
        } catch (error) {
            controller.textContent = "Offline";
            controller.classList.remove("status-checking", "status-online");
            controller.classList.add("status-offline");
            updateTrafficMood("offline", []);
            updated.textContent = "Unable to retrieve telemetry";
            console.error("StreamLight telemetry error:", error);
        }
    }

    refresh();
    setInterval(refresh, 3000);
});
