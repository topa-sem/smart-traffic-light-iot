document.addEventListener("DOMContentLoaded", () => {
    const avatarPicker = document.getElementById("avatarPicker");
    const avatarInput = document.getElementById("avatarInput");
    const avatarPreview = document.getElementById("avatarPreview");
    const avatarPlaceholder = document.getElementById("avatarPlaceholder");
    const dropzone = document.getElementById("profileDropzone");
    const filesInput = document.getElementById("profileFilesInput");
    const stagedFiles = document.getElementById("stagedFiles");

    if (!avatarPicker || !avatarInput || !avatarPreview || !avatarPlaceholder ||
        !dropzone || !filesInput || !stagedFiles) return;

    let previewUrl = null;
    let stagedFileList = [];
    const avatarStorageKey = "streamlight-avatar";

    function formatFileSize(bytes) {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
        return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    }

    function renderStagedFiles() {
        if (!stagedFileList.length) {
            stagedFiles.innerHTML = '<p class="staged-empty"><i class="fa-solid fa-inbox"></i> No files staged yet.</p>';
            return;
        }

        stagedFiles.innerHTML = stagedFileList.map(file => `
            <div class="staged-file">
                <p class="staged-file-name">
                    <i class="fa-solid fa-file-lines"></i>
                    <span title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</span>
                </p>
                <span class="staged-file-size">${formatFileSize(file.size)}</span>
            </div>
        `).join("");
    }

    function escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, character => ({
            "&": "&amp;", "<": "&lt;", ">": "&gt;",
            '"': "&quot;", "'": "&#039;"
        })[character]);
    }

    function stageFiles(fileList) {
        stagedFileList = [...stagedFileList, ...Array.from(fileList)];
        renderStagedFiles();
    }

    avatarPicker.addEventListener("click", () => avatarInput.click());
    avatarInput.addEventListener("change", () => {
        const [file] = avatarInput.files;
        if (!file || !file.type.startsWith("image/")) return;

        if (previewUrl) URL.revokeObjectURL(previewUrl);
        previewUrl = URL.createObjectURL(file);
        avatarPreview.src = previewUrl;
        avatarPreview.hidden = false;
        avatarPlaceholder.hidden = true;
        window.dispatchEvent(new CustomEvent("streamlight:avatarchange", {
            detail: { src: previewUrl }
        }));

        const reader = new FileReader();
        reader.addEventListener("load", () => {
            if (typeof reader.result === "string") {
                localStorage.setItem(avatarStorageKey, reader.result);
                window.dispatchEvent(new CustomEvent("streamlight:avatarchange", {
                    detail: { src: reader.result }
                }));
            }
        });
        reader.readAsDataURL(file);
    });

    dropzone.addEventListener("click", event => {
        if (event.target !== filesInput) filesInput.click();
    });
    dropzone.addEventListener("keydown", event => {
        if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            filesInput.click();
        }
    });
    filesInput.addEventListener("change", () => stageFiles(filesInput.files));

    ["dragover", "dragenter"].forEach(eventName => {
        dropzone.addEventListener(eventName, event => {
            event.preventDefault();
            dropzone.classList.add("is-dragging");
        });
    });
    ["dragleave", "dragend"].forEach(eventName => {
        dropzone.addEventListener(eventName, () => dropzone.classList.remove("is-dragging"));
    });
    dropzone.addEventListener("drop", event => {
        event.preventDefault();
        dropzone.classList.remove("is-dragging");
        stageFiles(event.dataTransfer.files);
    });

    window.addEventListener("beforeunload", () => {
        if (previewUrl) URL.revokeObjectURL(previewUrl);
    });
});
