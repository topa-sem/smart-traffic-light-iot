(() => {
    const root = document.documentElement;
    const button = document.getElementById("themeToggle");
    const avatar = document.getElementById("headerAvatar");
    const avatarPlaceholder = document.getElementById("headerAvatarPlaceholder");
    const avatarStorageKey = "streamlight-avatar";

    function updateHeaderAvatar(src) {
        if (!avatar || !avatarPlaceholder || !src) return;
        avatar.src = src;
        avatar.hidden = false;
        avatarPlaceholder.hidden = true;
    }

    updateHeaderAvatar(localStorage.getItem(avatarStorageKey));
    window.addEventListener("streamlight:avatarchange", event => {
        updateHeaderAvatar(event.detail && event.detail.src);
    });

    if (!button) return;

    const savedTheme = localStorage.getItem("streamlight-theme") || "dark";
    root.dataset.theme = savedTheme;

    function updateButton() {
        const isDark = root.dataset.theme === "dark";
        button.innerHTML = isDark
            ? '<i class="fa-solid fa-sun"></i>'
            : '<i class="fa-solid fa-moon"></i>';
        button.setAttribute("aria-label", isDark ? "Switch to light mode" : "Switch to dark mode");
    }

    button.addEventListener("click", () => {
        root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark";
        localStorage.setItem("streamlight-theme", root.dataset.theme);
        updateButton();
        window.dispatchEvent(new CustomEvent("streamlight:themechange"));
    });

    updateButton();
})();