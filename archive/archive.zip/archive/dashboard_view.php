<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StreamLight | Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/smarttraffic/css/dashboard.css?v=13">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-wrapper">
        <header class="topbar">
            <div class="search-box">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="search" placeholder="Search intersections, alerts..." aria-label="Search">
            </div>
            <div class="header-right-actions">
                <button class="icon-btn" id="themeToggle" type="button" aria-label="Switch theme">
                    <i class="fa-solid fa-sun"></i>
                </button>
                <a class="google-profile-btn" href="settings.php" aria-label="Open admin profile settings">
                    <div class="avatar-circle-top">
                        <img id="headerAvatar" alt="" hidden>
                        <i id="headerAvatarPlaceholder" class="fa-solid fa-user"></i>
                    </div>
                    <div class="profile-text-container">
                        <h5><?= htmlspecialchars($username ?? 'Admin') ?></h5>
                        <p>StreamLight Admin</p>
                    </div>
                </a>
                <a class="logout-link" href="logout.php" aria-label="Log out">
                    <i class="fa-solid fa-power-off"></i>
                </a>
            </div>
        </header>

        <main class="dashboard-body">
            <section class="header-row">
                <div>
                    <p class="eyebrow">BUKIT BINTANG, KUALA LUMPUR</p>
                    <h1><i class="fa-solid fa-chart-line"></i> Traffic overview</h1>
                </div>
                <div class="filter-controls">
                    <select class="select-input" id="intersectionSelect" aria-label="Intersection">
                        <option value="bukit-bintang">Jalan Bukit Bintang &amp; Jalan Sultan Ismail</option>
                    </select>
                    <span class="live-pill"><span></span> StreamLight Active</span>
                    <span class="status-chip chip-orange" id="trafficMood">
                        <i class="fa-solid fa-satellite-dish"></i> Connecting
                    </span>
                </div>
            </section>

            <section class="metrics-grid">
                <article class="metric-card">
                    <p class="metric-label"><i class="fa-solid fa-location-dot"></i> Monitored intersection</p>
                    <p class="metric-value">01</p>
                    <p class="metric-subtitle">Bukit Bintang, Kuala Lumpur</p>
                    <i class="fa-solid fa-location-dot metric-icon orange"></i>
                </article>
                <article class="metric-card">
                    <p class="metric-label"><i class="fa-solid fa-road"></i> Approaches reporting</p>
                    <p class="metric-value" id="activeLaneCount">—</p>
                    <p class="metric-subtitle">Lanes with received telemetry</p>
                    <i class="fa-solid fa-road metric-icon orange"></i>
                </article>
                <article class="metric-card">
                    <p class="metric-label"><i class="fa-solid fa-car"></i> Vehicles detected</p>
                    <p class="metric-value" id="vehicleTotal">—</p>
                    <p class="metric-subtitle">Current reported lane counts</p>
                    <i class="fa-solid fa-car metric-icon orange"></i>
                </article>
                <article class="metric-card">
                    <p class="metric-label"><i class="fa-solid fa-microchip"></i> Controller status</p>
                    <p class="metric-value metric-status status-checking" id="controllerStatus">Checking</p>
                    <p class="metric-subtitle">Intersection sync · latest API response</p>
                    <i class="fa-solid fa-microchip metric-icon green"></i>
                </article>
            </section>

            <section class="panel">
                <div class="panel-header">
                    <div>
                        <h2 class="panel-title"><i class="fa-solid fa-chart-column"></i> Live traffic by approach</h2>
                        <p class="panel-description">Latest vehicle counts received from the ESP32</p>
                    </div>
                    <span class="updated-label" id="lastUpdated">Waiting for data…</span>
                </div>
                <div class="chart-container"><canvas id="predictionChart"></canvas></div>
            </section>

            <section class="panel">
                <div class="panel-header">
                    <div>
                        <h2 class="panel-title"><i class="fa-solid fa-traffic-light"></i> Four-way signal status</h2>
                        <p class="panel-description">Signal states reported by the lane-status table</p>
                    </div>
                    <span class="monitor-only"><i class="fa-solid fa-eye"></i> Monitoring only</span>
                </div>
                <div class="lane-grid" id="laneGrid">
                    <p class="empty-state">Waiting for lane telemetry…</p>
                </div>
                <p class="panel-note">
                    Dashboard controls are not connected to the physical signal controller yet.
                    Do not use this display to operate public-road traffic signals.
                </p>
            </section>
        </main>
    </div>

    <script src="/smarttraffic/js/theme.js"></script>
    <script src="/smarttraffic/js/dashboard_charts.js"></script>
    <script src="/smarttraffic/js/intersection_status.js"></script>
</body>
</html>