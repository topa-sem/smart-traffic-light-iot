<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

function respond(array $payload, int $code = 200): void {
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ESP32 telemetry input only. This endpoint does not issue light commands.
    $laneId = filter_input(INPUT_POST, 'lane_id', FILTER_VALIDATE_INT);
    $vehicleCount = filter_input(INPUT_POST, 'vehicle_count', FILTER_VALIDATE_INT);
    $signalState = strtoupper(trim($_POST['signal_state'] ?? 'RED'));

    if (!$laneId || $vehicleCount === false || $vehicleCount === null || $vehicleCount < 0) {
        respond(['status' => 'error', 'message' => 'Invalid lane_id or vehicle_count'], 400);
    }
    if (!in_array($signalState, ['RED', 'YELLOW', 'GREEN'], true)) {
        respond(['status' => 'error', 'message' => 'Invalid signal_state'], 400);
    }

    $stmt = $conn->prepare(
        "UPDATE lane_status SET vehicle_count = ?, signal_state = ? WHERE lane_id = ?"
    );
    if (!$stmt) respond(['status' => 'error', 'message' => 'Database prepare failed'], 500);
    $stmt->bind_param("isi", $vehicleCount, $signalState, $laneId);
    $stmt->execute();

    if ($stmt->affected_rows === 0 && $stmt->errno) {
        respond(['status' => 'error', 'message' => 'Could not update lane'], 500);
    }

    $log = $conn->prepare(
        "INSERT INTO traffic_logs (lane_id, vehicle_count) VALUES (?, ?)"
    );
    if (!$log) respond(['status' => 'error', 'message' => 'Log prepare failed'], 500);
    $log->bind_param("ii", $laneId, $vehicleCount);
    $log->execute();

    respond(['status' => 'success']);
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respond(['status' => 'error', 'message' => 'Method not allowed'], 405);
}

$result = $conn->query(
    "SELECT lane_id, lane_name, signal_state, vehicle_count
     FROM lane_status ORDER BY lane_id ASC"
);
if (!$result) respond(['status' => 'error', 'message' => 'Could not read lane status'], 500);

$lanes = [];
while ($row = $result->fetch_assoc()) {
    $row['lane_id'] = (int)$row['lane_id'];
    $row['vehicle_count'] = (int)$row['vehicle_count'];
    $lanes[] = $row;
}

respond(['status' => 'online', 'lanes' => $lanes]);
?>