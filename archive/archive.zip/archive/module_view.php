<?php
// Shared placeholder view for StreamLight modules.
// Each module page sets $pageTitle and $pageDescription before including this file.
$currentModule = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StreamLight | <?= htmlspecialchars($pageTitle) ?></title>
    <link rel="stylesheet" href="/smarttraffic/css/dashboard.css?v=11">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-wrapper">
        <header class="topbar">
            <div class="search-box">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="search" placeholder="Search StreamLight..." aria-label="Search">
            </div>
            <div class="header-right-actions">
                <button class="icon-btn" id="themeToggle" type="button" aria-label="Switch theme">
                    <i class="fa-solid fa-sun"></i>
                </button>
                <a class="google-profile-btn" href="settings.php" aria-label="Open admin profile settings">
                    <div class="avatar-circle-top">
                        <img id="headerAvatar" alt="" hidden>
                        <i id="headerAvatarPlaceholder" class="fa-solid fa-user"></i>
                    </div>
                    <div class="profile-text-container">
                        <h5><?= htmlspecialchars($username ?? 'Admin') ?></h5>
                        <p>StreamLight Admin</p>
                    </div>
                </a>
                <a class="logout-link" href="logout.php" aria-label="Log out">
                    <i class="fa-solid fa-power-off"></i>
                </a>
            </div>
        </header>
        <main class="dashboard-body">
            <section class="header-row">
                <div>
                    <p class="eyebrow">BUKIT BINTANG, KUALA LUMPUR</p>
                    <h1><?= htmlspecialchars($pageTitle) ?></h1>
                    <p class="panel-description"><?= htmlspecialchars($pageDescription) ?></p>
                </div>
            </section>
            <section class="panel">
                <h2 class="panel-title"><?= htmlspecialchars($pageTitle) ?></h2>
                <p class="panel-description">
                    This page is connected to the StreamLight layout. Its feature module
                    still needs to be implemented.
                </p>
                <p class="panel-note">
                    Data and controls will appear here after the relevant database tables,
                    sensors and controller functions are connected.
                </p>
            </section>
        </main>
    </div>
    <script src="/smarttraffic/js/theme.js"></script>
</body>
</html>
