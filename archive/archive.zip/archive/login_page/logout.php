<?php
session_start();
$_SESSION = array();
session_destroy();

// Redirect back to login.php within the login_page folder
header("Location: login.php");
exit;
?>