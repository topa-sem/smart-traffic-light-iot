<?php
session_start();

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : "";
unset($_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STMS Admin Portal | ESP32 Traffic Control</title>
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        body {
            /* Replace background.gif with your actual image file name */
            background: url('login_bg.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #e6edf3;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .login-card {
            background: rgba(22, 27, 34, 0.85);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(0, 242, 254, 0.25);
            border-radius: 16px;
            padding: 36px 32px;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 16px 40px rgba(0, 0, 0, 0.6), 0 0 20px rgba(0, 242, 254, 0.1);
        }
        .header { text-align: center; margin-bottom: 28px; }
        .logo-icon { font-size: 2.2rem; color: #00f2fe; margin-bottom: 10px; filter: drop-shadow(0 0 8px rgba(0, 242, 254, 0.6)); }
        .header h2 { color: #ffffff; font-size: 1.5rem; font-weight: 700; margin-bottom: 4px; }
        .header p { color: #8b949e; font-size: 0.85rem; }
        .status-badge {
            display: inline-flex; align-items: center; gap: 6px;
            background: rgba(63, 185, 80, 0.1); color: #3fb950;
            padding: 5px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 600;
            margin-top: 12px; border: 1px solid rgba(63, 185, 80, 0.3);
        }
        .pulse-dot {
            width: 8px; height: 8px; background-color: #3fb950;
            border-radius: 50%; box-shadow: 0 0 8px #3fb950;
            animation: pulse 1.8s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(63, 185, 80, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(63, 185, 80, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(63, 185, 80, 0); }
        }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-size: 0.85rem; color: #8b949e; }
        
        .input-wrapper { position: relative; display: flex; align-items: center; }
        .input-wrapper .left-icon {
            position: absolute; left: 14px; color: #484f58; font-size: 0.95rem; transition: color 0.2s;
        }
        .input-wrapper .toggle-eye {
            position: absolute; right: 14px; color: #8b949e; cursor: pointer; font-size: 0.95rem; transition: color 0.2s;
        }
        .input-wrapper .toggle-eye:hover { color: #00f2fe; }

        input[type="text"], input[type="password"] {
            width: 100%; padding: 12px 42px 12px 40px;
            background: rgba(13, 17, 23, 0.9); border: 1px solid #30363d;
            border-radius: 8px; color: #ffffff; font-size: 0.95rem; outline: none; transition: all 0.25s;
        }
        input:focus { border-color: #00f2fe; box-shadow: 0 0 10px rgba(0, 242, 254, 0.25); }
        input:focus ~ .left-icon { color: #00f2fe; }

        .btn-submit {
            width: 100%; padding: 12px;
            background: linear-gradient(135deg, #00f2fe 0%, #4facfe 100%);
            color: #06090e; border: none; border-radius: 8px; font-size: 1rem; font-weight: 700;
            cursor: pointer; transition: transform 0.2s, box-shadow 0.2s; margin-top: 6px;
        }
        .btn-submit:hover { transform: translateY(-1px); box-shadow: 0 4px 15px rgba(0, 242, 254, 0.4); }
        .error-msg {
            background: rgba(248, 81, 73, 0.12); color: #f85149;
            border: 1px solid rgba(248, 81, 73, 0.3); padding: 10px 14px;
            border-radius: 8px; font-size: 0.85rem; margin-bottom: 20px;
            display: flex; align-items: center; gap: 8px;
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="header">
        <div class="logo-icon"><i class="fa-solid fa-traffic-light"></i></div>
        <h2>Smart Traffic Admin</h2>
        <p>ESP32 Microcontroller Gateway Control</p>
        <div class="status-badge">
            <span class="pulse-dot"></span> ESP32 Gateway: Connected
        </div>
    </div>

    <?php if (!empty($error)): ?>
        <div class="error-msg">
            <i class="fa-solid fa-circle-exclamation"></i>
            <span><?php echo htmlspecialchars($error); ?></span>
        </div>
    <?php endif; ?>

    <form action="login_process.php" method="POST">
        <div class="form-group">
            <label for="username">Admin Username</label>
            <div class="input-wrapper">
                <input type="text" id="username" name="username" placeholder="e.g. admin" required autocomplete="off">
                <i class="fa-solid fa-user-shield left-icon"></i>
            </div>
        </div>

        <div class="form-group">
            <label for="password">Security Access Code</label>
            <div class="input-wrapper">
                <input type="password" id="password" name="password" placeholder="••••••••" required>
                <i class="fa-solid fa-key left-icon"></i>
                <!-- Default icon: slash eye (hidden) -->
                <i class="fa-solid fa-eye-slash toggle-eye" id="togglePassword"></i>
            </div>
        </div>

        <button type="submit" class="btn-submit">
            Authenticate Gateway <i class="fa-solid fa-arrow-right-to-bracket" style="margin-left: 6px;"></i>
        </button>
    </form>
</div>

<script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password');
    
    togglePassword.addEventListener('click', function () {
    const isPassword = password.getAttribute('type') === 'password';
    
    // Switch input type
    password.setAttribute('type', isPassword ? 'text' : 'password');
    
    // Switch eye icon: open eye when visible, slashed eye when hidden
    if (isPassword) {
        this.classList.remove('fa-eye-slash');
        this.classList.add('fa-eye');
    } else {
        this.classList.remove('fa-eye');
        this.classList.add('fa-eye-slash');
    }
});
</script>

</body>
</html>