<?php
session_start();

// 1. Go up one directory level to access db.php in root
require_once '../db.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        $_SESSION['error'] = "Please enter both username and password.";
        header("Location: login.php");
        exit;
    }

    // Prepare statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Verify password (plain text or password_verify if hashed)
        if ($password === $user['password'] || password_verify($password, $user['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_user'] = $user['username'];
            
            // 2. CRITICAL FIX: Go up one directory level (../) to reach dashboard.php in root
            header("Location: ../dashboard.php");
            exit;
        } else {
            $_SESSION['error'] = "Invalid access code.";
            header("Location: login.php");
            exit;
        }
    } else {
        $_SESSION['error'] = "Admin user not found.";
        header("Location: login.php");
        exit;
    }
} else {
    header("Location: login.php");
    exit;
}
?>