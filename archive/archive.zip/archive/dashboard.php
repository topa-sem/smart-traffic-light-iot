
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Check admin authentication
if (
    !isset($_SESSION['admin_logged_in']) ||
    $_SESSION['admin_logged_in'] !== true
) {
    header("Location: /smarttraffic/login_page/login.php");
    exit;
}

// Get logged-in username
$username = $_SESSION['admin_user'] ?? 'Admin';

// Load dashboard view
require_once 'dashboard_view.php';
?>