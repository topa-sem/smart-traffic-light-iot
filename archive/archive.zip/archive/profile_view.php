<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StreamLight | <?= htmlspecialchars($pageTitle) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/smarttraffic/css/dashboard.css?v=12">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-wrapper">
        <header class="topbar">
            <div class="search-box">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="search" placeholder="Search StreamLight..." aria-label="Search">
            </div>
            <div class="header-right-actions">
                <button class="icon-btn" id="themeToggle" type="button" aria-label="Switch theme">
                    <i class="fa-solid fa-sun"></i>
                </button>
                <a class="google-profile-btn" href="settings.php" aria-label="Open admin profile settings">
                    <div class="avatar-circle-top">
                        <img id="headerAvatar" alt="" hidden>
                        <i id="headerAvatarPlaceholder" class="fa-solid fa-user"></i>
                    </div>
                    <div class="profile-text-container">
                        <h5><?= htmlspecialchars($username ?? 'Admin') ?></h5>
                        <p>StreamLight Admin</p>
                    </div>
                </a>
                <a class="logout-link" href="logout.php" aria-label="Log out">
                    <i class="fa-solid fa-power-off"></i>
                </a>
            </div>
        </header>

        <main class="dashboard-body">
            <section class="header-row">
                <div>
                    <p class="eyebrow">STREAMLIGHT ADMIN CONSOLE</p>
                    <h1><i class="fa-solid fa-user-gear"></i> <?= htmlspecialchars($pageTitle) ?></h1>
                    <p class="panel-description"><?= htmlspecialchars($pageDescription) ?></p>
                </div>
                <span class="status-chip chip-green"><i class="fa-solid fa-lock"></i> Private workspace</span>
            </section>

            <section class="profile-card panel" aria-labelledby="profileSettingsTitle">
                <div class="panel-header">
                    <div>
                        <h2 class="panel-title" id="profileSettingsTitle"><i class="fa-solid fa-id-card"></i> Operator details</h2>
                        <p class="panel-description">Update the information shown to your operations team.</p>
                    </div>
                </div>

                <form class="profile-form" onsubmit="return false">
                    <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 24px;">
                        <div id="avatarPicker" role="button" tabindex="0"
                            aria-label="Choose a profile photo" aria-describedby="avatarHint"
                            style="width: 80px; height: 80px; border-radius: 50%; background-color: #1e291b; border: 2px solid #2e7d32; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden; cursor: pointer;">
                            <img id="avatarPreview" alt="Profile photo preview" hidden
                                style="width: 100%; height: 100%; object-fit: cover;">
                            <span id="avatarPlaceholder" style="font-size: 24px;">📷</span>
                        </div>
                        <input id="avatarInput" type="file" accept="image/*" hidden>
                        <div>
                            <h3 style="margin: 0 0 4px 0; font-size: 18px; color: #fff;"><?= htmlspecialchars($username ?? 'Admin') ?></h3>
                            <p id="avatarHint" style="margin: 0; font-size: 14px; color: #a5d6a7;">Click the avatar to choose a new photo.</p>
                        </div>
                    </div>

                    <div class="profile-fields">
                        <label class="profile-field">
                            <span>Full name</span>
                            <input type="text" name="full_name" value="<?= htmlspecialchars($username ?? '') ?>" autocomplete="name">
                        </label>
                        <label class="profile-field">
                            <span>Date of birth</span>
                            <input type="date" name="date_of_birth" autocomplete="bday">
                        </label>
                        <label class="profile-field">
                            <span>System role / permissions level</span>
                            <select name="role">
                                <option value="administrator">Administrator</option>
                                <option value="operator">Traffic operator</option>
                                <option value="viewer">Read-only viewer</option>
                            </select>
                        </label>
                        <label class="profile-field">
                            <span>Email address</span>
                            <input type="email" name="email" placeholder="admin@example.com" autocomplete="email">
                        </label>
                    </div>

                    <div class="profile-dropzone" id="profileDropzone" tabindex="0"
                        role="button" aria-label="Stage configuration files or reports">
                        <i class="fa-solid fa-cloud-arrow-up dropzone-icon"></i>
                        <div>
                            <strong>Drop reports or configuration files here</strong>
                            <p>Drag files into this area, or click to browse.</p>
                        </div>
                        <input id="profileFilesInput" type="file" multiple hidden>
                    </div>

                    <div class="profile-form-actions">
                        <button class="profile-save-button" type="submit">
                            <i class="fa-solid fa-check"></i> Save Changes
                        </button>
                    </div>
                </form>

                <div class="staged-files" id="stagedFiles" aria-live="polite">
                    <p class="staged-empty"><i class="fa-solid fa-inbox"></i> No files staged yet.</p>
                </div>
                <p class="panel-note"><i class="fa-solid fa-circle-info"></i> Profile edits are currently local to this browser session.</p>
            </section>
        </main>
    </div>

    <script src="/smarttraffic/js/theme.js"></script>
    <script src="/smarttraffic/js/profile_actions.js"></script>
</body>
</html>
