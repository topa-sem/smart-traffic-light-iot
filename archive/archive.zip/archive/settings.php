<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: /smarttraffic/login_page/login.php");
    exit;
}

$username = $_SESSION['admin_user'] ?? 'Admin';
$pageTitle = 'Admin Profile Settings';
$pageDescription = 'Keep your operator details and working files ready for every shift.';
require 'profile_view.php';
?>
