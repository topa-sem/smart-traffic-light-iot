<a class="sidebar-brand traffic-logo" href="dashboard.php" aria-label="StreamLight admin dashboard">
    <svg class="traffic-logo-mark" viewBox="0 0 64 72" role="img" aria-labelledby="traffic-logo-title traffic-logo-description">
        <title id="traffic-logo-title">StreamLight traffic signal</title>
        <desc id="traffic-logo-description">A friendly three-light traffic signal icon</desc>
        <defs>
            <linearGradient id="traffic-housing-gradient" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#293548" />
                <stop offset="1" stop-color="#111827" />
            </linearGradient>
            <linearGradient id="traffic-red-gradient" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#ff867f" />
                <stop offset="1" stop-color="#f0444b" />
            </linearGradient>
            <linearGradient id="traffic-amber-gradient" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#ffd978" />
                <stop offset="1" stop-color="#f5a623" />
            </linearGradient>
            <linearGradient id="traffic-green-gradient" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#8cf6ad" />
                <stop offset="1" stop-color="#32c875" />
            </linearGradient>
            <filter id="traffic-logo-shadow" x="-35%" y="-25%" width="170%" height="160%">
                <feDropShadow dx="0" dy="4" stdDeviation="3" flood-color="#000000" flood-opacity=".35" />
            </filter>
            <filter id="traffic-red-glow" x="-100%" y="-100%" width="300%" height="300%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                </feMerge>
            </filter>
        </defs>
        <g transform="rotate(-6 32 36)" filter="url(#traffic-logo-shadow)">
            <rect class="traffic-housing" x="14" y="4" width="36" height="64" rx="8" fill="url(#traffic-housing-gradient)" />
            <path class="traffic-housing-highlight" d="M22 8h14a4 4 0 0 1 4 4v48" fill="none" stroke="#ffffff" stroke-opacity=".12" stroke-width="2" stroke-linecap="round" />
            <g class="traffic-light traffic-light--red" filter="url(#traffic-red-glow)">
                <circle class="traffic-light-core" cx="32" cy="17" r="7" fill="url(#traffic-red-gradient)" />
                <ellipse class="traffic-light-gloss" cx="29.5" cy="14.5" rx="2.5" ry="1.7" fill="#ffffff" fill-opacity=".72" />
            </g>
            <g class="traffic-light traffic-light--amber">
                <circle class="traffic-light-core" cx="32" cy="36" r="7" fill="url(#traffic-amber-gradient)" />
                <ellipse class="traffic-light-gloss" cx="29.5" cy="33.5" rx="2.5" ry="1.7" fill="#ffffff" fill-opacity=".72" />
            </g>
            <g class="traffic-light traffic-light--green">
                <circle class="traffic-light-core" cx="32" cy="55" r="7" fill="url(#traffic-green-gradient)" />
                <ellipse class="traffic-light-gloss" cx="29.5" cy="52.5" rx="2.5" ry="1.7" fill="#ffffff" fill-opacity=".72" />
            </g>
        </g>
    </svg>
    <span class="traffic-logo-name">StreamLight</span>
    <span class="traffic-logo-badge">ADMIN</span>
</a>
