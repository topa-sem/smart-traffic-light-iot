<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar">
    <div>
        <?php include __DIR__ . '/traffic_logo.php'; ?>

        <div class="menu-group">
            <div class="menu-title">Main</div>
            <a href="dashboard.php" class="nav-item <?php echo ($currentPage == 'dashboard.php') ? 'active' : ''; ?>">
                <div><i class="fa-solid fa-table-cells-large"></i> Dashboard</div>
            </a>
            <a href="analytics.php" class="nav-item <?php echo ($currentPage == 'analytics.php') ? 'active' : ''; ?>">
                <div><i class="fa-solid fa-chart-line"></i> Analytics</div>
            </a>
            <a href="alerts.php" class="nav-item <?php echo ($currentPage == 'alerts.php') ? 'active' : ''; ?>">
                <div><i class="fa-solid fa-triangle-exclamation"></i> Alerts</div>
                <span class="badge">2</span>
            </a>
            <a href="intersections.php" class="nav-item <?php echo ($currentPage == 'intersections.php') ? 'active' : ''; ?>">
                <div><i class="fa-solid fa-code-fork"></i> Intersections</div>
            </a>
        </div>

        <div class="menu-group">
            <div class="menu-title">System</div>
            <a href="schedule.php" class="nav-item <?php echo ($currentPage == 'schedule.php') ? 'active' : ''; ?>">
                <div><i class="fa-regular fa-clock"></i> Schedule</div>
            </a>
            <a href="cameras.php" class="nav-item <?php echo ($currentPage == 'cameras.php') ? 'active' : ''; ?>">
                <div><i class="fa-solid fa-video"></i> Cameras</div>
            </a>
            <a href="settings.php" class="nav-item <?php echo ($currentPage == 'settings.php') ? 'active' : ''; ?>">
                <div><i class="fa-solid fa-gear"></i> Settings</div>
            </a>
        </div>
    </div>

    <div class="sidebar-footer">
        <div class="system-card">
            <div class="system-card-header">
                <span><i class="fa-solid fa-power-off"></i> System Status</span>
                <span class="status-badge">Online</span>
            </div>
            <div class="stat-meta"><span>Uptime:</span><span style="color:#f0f6fc;">99.9%</span></div>
            <div class="stat-meta"><span>Response Time:</span><span style="color:#f0f6fc;">102ms</span></div>
        </div>
    </div>
</aside>